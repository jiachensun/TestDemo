package com.bairong.antifrauddemo;

import android.app.Application;
import android.text.TextUtils;
import android.util.Log;

import com.bairong.antifrauddemo.utils.CrashHandler;
import com.bairong.mobile.BrAgent;
import com.bairong.mobile.BrLocationType;

import java.util.Random;

public class BrApplication extends Application {

    private static BrApplication instance = null;
    private boolean isCompress = false;
    private boolean isEncrypt = false;
    private BrLocationType locationType = BrLocationType.BrLocaitonTypeRequestAuthorization;
    private String timeout;
    private String initRequestData;

    /** app server */
    private String brGID;
    private boolean isServer = true;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        CrashHandler.getInstance().init(this);

        BrApplication.getInstance().setBrGID(BrAgent.brGetDeviceGid(this));
    }

    public static BrApplication getInstance() {
        return instance;
    }

    public boolean isCompress() {
        return isCompress;
    }

    public void setCompress(boolean compress) {
        isCompress = compress;
    }

    public boolean isEncrypt() {
        return isEncrypt;
    }

    public void setEncrypt(boolean encrypt) {
        isEncrypt = encrypt;
    }

    public String getInitRequestData() {
        return initRequestData;
    }

    public void setInitRequestData(String initRequestData) {
        this.initRequestData = initRequestData;
    }

    public BrLocationType getLocationType() {
        return locationType;
    }

    public void setLocationType(BrLocationType locationType) {
        this.locationType = locationType;
    }

    public String getTimeout() {
        return timeout;
    }

    public void setTimeout(String timeout) {
        this.timeout = timeout;
    }

    public String getBrGID() {
        return getEncryptGid(brGID);
    }

    public void setBrGID(String brGID) {
        this.brGID = brGID;
    }

    public boolean isServer() {
        return isServer;
    }

    public void setServer(boolean server) {
        isServer = server;
    }

    /**
     * 1、取时间戳（毫秒级）第8位到最后一位 得到数字串->timeStr
     * 2、在（1，6）随机一个数a
     * 3、timeStr+gid ->newStr（新数字串）
     * 4、将新数字串的每一位数字与a做和，然后转换成十六进制数，得到加密串EncryptStr
     * 5、EncryptStr+a 就是想相应的返回加密串
     * PS:暂定十六进制字母小写
     */
    public String getEncryptGid(String gid) {
        if (TextUtils.isEmpty(gid)) {
            return null;
        }
        try {
            Random random = new Random();
            int a = random.nextInt(6) + 1;
//            int a = 4;
            String timeStr = String.valueOf(System.currentTimeMillis());
            if (!TextUtils.isEmpty(timeStr) && timeStr.length() < 8) {
                return gid;
            }
            timeStr = timeStr.substring(8) + gid;
//            timeStr = "18582" + gid;
            String resultGid = "";
            for (char b : timeStr.toCharArray()) {
                int intB = Integer.parseInt(String.valueOf(b));
                int intSum = intB + a;
                String hexSum = Integer.toHexString(intSum);
                resultGid = resultGid + hexSum;
            }
            return resultGid + a;
        } catch (Exception e) {
            return gid;
        }
    }
}
