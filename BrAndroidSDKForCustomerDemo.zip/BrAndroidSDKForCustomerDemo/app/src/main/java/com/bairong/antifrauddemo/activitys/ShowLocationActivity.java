package com.bairong.antifrauddemo.activitys;

import android.Manifest;
import android.app.ActivityManager;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.bairong.antifrauddemo.R;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class ShowLocationActivity extends AppCompatActivity {

    private TextView gpsTextView;
    private TextView wifiTextView;

    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_location);

        gpsTextView = findViewById(R.id.tv_show_gps);
        wifiTextView = findViewById(R.id.tv_show_wifi);

        gpsTextView.setMovementMethod(ScrollingMovementMethod.getInstance());
        wifiTextView.setMovementMethod(ScrollingMovementMethod.getInstance());

        checkPermissions();

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    public void onClickBeginLoacte(View view) {

        if (null == locationManager) {
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        } else {
            return;
        }

        getXposedInfo();

        locationByGps();
        locationByNet();
//        locationByPassive();
//        locationByFused();
    }

    private void showText(final TextView textView, final String text) {

        if (null != textView) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (TextUtils.isEmpty(text)) {
                        textView.setText("");
                        return;
                    }
                    String textResult = textView.getText().toString() + text + "\n";
                    textView.setText(textResult);
                }
            });
        }
    }

    private void locationByGps() {
        if (null == locationManager) {
            return;
        }
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (Exception e) {
            //()
        }
    }

    private void locationByNet() {
        if (null == locationManager) {
            return;
        }
        try {
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
        } catch (SecurityException e) {
            //()
        } catch (Exception e) {
            //()
        }
    }

    private void locationByPassive() {
        if (null == locationManager) {
            return;
        }
        try {
            locationManager.requestLocationUpdates(LocationManager.PASSIVE_PROVIDER, 0, 0, locationListener);
        } catch (SecurityException e) {
            //()
        } catch (Exception e) {
            //()
        }
    }

    private void locationByFused() {
        if (null == locationManager) {
            return;
        }
        try {
            locationManager.requestLocationUpdates("fused", 0, 0, locationListener);
        } catch (SecurityException e) {
            //()
        } catch (Exception e) {
            //()
        }
    }

    private void doDeXposed() {
        try {
            Field v0_1 = ClassLoader.getSystemClassLoader().loadClass("de.robv.android.xposed.XposedBridge").getDeclaredField("disableHooks");
            v0_1.setAccessible(true);
            v0_1.set(null, Boolean.valueOf(true));
        } catch (Exception e) {
            //
        }
    }

    private static final String GPS_METHOD = "android.location.LocationManager";
    private void getXposedInfo() {

        try {
            Field v0_2 = ClassLoader.getSystemClassLoader().loadClass("de.robv.android.xposed.XposedBridge").getDeclaredField("sHookedMethodCallbacks");
            v0_2.setAccessible(true);
            Map hookMethods = (Map) v0_2.get(null);
            if (hookMethods.toString().contains(GPS_METHOD)) {
                Log.i("getXposedInfo", "hook location");
            }
        } catch (Exception e) {
            Log.e("getXposedInfo", "sHookedMethodCallbacks:" + e);
        }
    }

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            if (null != location) {
                String providerL = location.getProvider();
                Log.i("LocationListener", providerL + ", " + location.toString());
                Log.d("LocationListener", "latitude:" + location.getLatitude()
                        + ", longitude:" + location.getLongitude()
                        + ", altitude:" + location.getAltitude()
                        + ", speed:" + location.getSpeed()
                        + ", accuracy:" + location.getAccuracy());
                if (providerL.equals(LocationManager.GPS_PROVIDER)) {
                    showText(gpsTextView, "latitude:" + location.getLatitude()
                            + ", longitude:" + location.getLongitude()
                            + ", altitude:" + location.getAltitude()
                            + ", speed:" + location.getSpeed()
                            + ", accuracy:" + location.getAccuracy());
                } else if (providerL.equals(LocationManager.NETWORK_PROVIDER)) {
                    showText(wifiTextView, "latitude:" + location.getLatitude()
                            + ", longitude:" + location.getLongitude()
                            + ", altitude:" + location.getAltitude()
                            + ", speed:" + location.getSpeed()
                            + ", accuracy:" + location.getAccuracy());
                } else if (providerL.equals(LocationManager.PASSIVE_PROVIDER)) {

                } else {

                }
            }
        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

            Log.i("LocationListener", "onStatusChanged, " + s + ", " + i);
        }

        @Override
        public void onProviderEnabled(String s) {

            Log.i("LocationListener", "onProviderEnabled, " + s);
        }

        @Override
        public void onProviderDisabled(String s) {

            Log.i("LocationListener", "onProviderDisabled, " + s);
        }
    };

    /**
     * 需要动态授权的权限
     */
    private ArrayList<String> permissionList = new ArrayList<String>(){{
        add(Manifest.permission.ACCESS_COARSE_LOCATION);
        add(Manifest.permission.ACCESS_FINE_LOCATION);
    }};

    /**
     * 检查授权情况，对于未授权情况进行动态授权
     */
    private void checkPermissions() {
        ArrayList<String> notPermissionList = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (String permission : permissionList) {
                if (ContextCompat.checkSelfPermission(this, permission)
                        != PackageManager.PERMISSION_GRANTED) {
                    notPermissionList.add(permission);
                }
            }
        }
        if (notPermissionList.size() > 0) {
            String [] needPerissions = notPermissionList.toArray(new String[notPermissionList.size()]);
            ActivityCompat.requestPermissions(this, needPerissions,1);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (null != locationManager) {
            locationManager.removeUpdates(locationListener);
            locationManager = null;
        }
    }

    public void onClickStopSimL(View view) {

        showText(gpsTextView, "");
        showText(wifiTextView, "");

        try {
            if (null != locationManager) {
                locationManager.clearTestProviderEnabled(LocationManager.NETWORK_PROVIDER);
                locationManager.clearTestProviderLocation(LocationManager.NETWORK_PROVIDER);
                locationManager.clearTestProviderStatus(LocationManager.NETWORK_PROVIDER);

                locationManager.clearTestProviderEnabled(LocationManager.GPS_PROVIDER);
                locationManager.clearTestProviderLocation(LocationManager.GPS_PROVIDER);
                locationManager.clearTestProviderStatus(LocationManager.GPS_PROVIDER);

                locationManager.removeTestProvider(LocationManager.NETWORK_PROVIDER);
                locationManager.removeTestProvider(LocationManager.GPS_PROVIDER);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onClickClear(View view) {

        showText(gpsTextView, "");
        showText(wifiTextView, "");
    }
}