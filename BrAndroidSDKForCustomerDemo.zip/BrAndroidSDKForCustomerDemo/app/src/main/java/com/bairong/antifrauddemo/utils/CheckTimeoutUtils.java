package com.bairong.antifrauddemo.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * @Author sjc
 * @Date 2020/1/13.
 * GitHub：
 * Email：jiachen.sun@credit.com
 * Description：
 */
public class CheckTimeoutUtils {
    private static final long TIMEOUTM = 0;
    private static final String TIMEOUTM_KEY = "br_time_out";
    /**
     * POC测试版本生效时间限制
     *
     * 第一次进入将时间保存在本地SDCard
     * 每次点击按钮和再次进入时：
     * 1、如果当前时间比保存早，表示系统时间被修改退出程序
     * 2、如果当前时间大于保存时间并且没有超出测试周期时长，则更新本地保存时间
     * 3、如果当前时间大于测试周期，退出程序
     */
    public static boolean checkTimeout(Context context, long currentTime) {
        if (TIMEOUTM == 0) {
            return false;
        }
        try {
            if (currentTime > TIMEOUTM) {
                putString(context, String.valueOf(currentTime));
                return true;
            }
            String timeout = getString(context);
            putString(context, String.valueOf(currentTime));
            if (currentTime < Long.valueOf(timeout)) {
                return true;
            }
        } catch (Exception e) {
            //
        }
        return false;
    }

    /**SharedPreference文件名**/
    private static final String BR_SP_NAME = "bairong_customer";

    private static void putString(Context context, String value) {
        if (context==null) {
            return;
        }
        SharedPreferences sharedPreferences = context.getSharedPreferences(BR_SP_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TIMEOUTM_KEY, value);
        editor.apply();
    }

    private static String getString(Context context){
        if (context==null) {
            return "";
        }
        SharedPreferences sharedPreferences = context.getSharedPreferences(BR_SP_NAME,Context.MODE_PRIVATE);
        return sharedPreferences.getString(TIMEOUTM_KEY,"");
    }
}
