package com.bairong.antifrauddemo.activitys;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bairong.antifrauddemo.BrApplication;
import com.bairong.antifrauddemo.BuildConfig;
import com.bairong.antifrauddemo.R;
import com.bairong.antifrauddemo.nanohttpd.NanoHTTPD;
import com.bairong.antifrauddemo.utils.CheckTimeoutUtils;
import com.bairong.mobile.BrAgent;
import com.bairong.mobile.BrLocationType;
import com.bairong.mobile.BrResponse;
import com.bairong.mobile.CallBack;

import org.json.JSONObject;


/**
 * Created by zhangwei on 17/4/1.
 */
public class EntranceActivity extends BaseActivity {
    private ImageView icon;
    private ImageView iv_init_status;
    private TextView tv_init_status;
    private TextView tv_init_gid;
    private BrResponse responsee;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_entrance;
    }

    @Override
    protected String getT() {
        return "标准模式";
    }

    @Override
    protected boolean getNeedBackIcon() {
        return true;
    }

    @Override
    protected void findViewById() {
        icon = findViewById(R.id.iv_antifraud_icon);
        iv_init_status = findViewById(R.id.iv_init_status);
        tv_init_status = findViewById(R.id.tv_init_status);
        tv_init_gid = findViewById(R.id.tv_init_gid);
    }

    @Override
    protected void initDate(Bundle savedInstanceState) {
        ((TextView) findViewById(R.id.tv_app_version)).setText(String.format("当前版本：%s", BuildConfig.VERSION_NAME));
        initBtnClick();
        doBrInit();
    }

    /**
     * 百融初始化
     */
    private void doBrInit() {
        showProgressHUD("初始化中");
        BrAgent.setDataCompress(BrApplication.getInstance().isCompress());
        BrAgent.setDataEncrypt(BrApplication.getInstance().isEncrypt());
        BrAgent.setLocationType(BrApplication.getInstance().getLocationType());
        BrAgent.brInit(BrApplication.getInstance(), "444333", new CallBack() {
            @Override
            public void message(BrResponse response) {
                if (response.getStart_time() != 0 && CheckTimeoutUtils.checkTimeout(EntranceActivity.this, response.getStart_time())) {
                    showToast(EntranceActivity.this, "授权到期，请联系相关人员");
                    System.exit(0);
                }
                updateUIGID(response);
                BrApplication.getInstance().setInitRequestData(BrAgent.getRequest());
            }
        });
    }

    private void updateUIGID(final BrResponse response) {
        responsee = response;
        dismissProgressHUD();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (response.getCode() == 0) {
                    try {
                        JSONObject jsonObject = new JSONObject(response.getData());
                        String gid = jsonObject.getString("gid");
                        if (!TextUtils.isEmpty(gid)) {
                            BrApplication.getInstance().setBrGID(gid);
                            iv_init_status.setBackgroundColor(getResources().getColor(R.color.green));
                            tv_init_status.setText("初始化成功，设备指纹为：");
                            tv_init_gid.setText(gid);
                        } else {
                            iv_init_status.setBackgroundColor(getResources().getColor(R.color.red));
                            tv_init_status.setText("初始化失败：");
                            tv_init_gid.setText("gid = null");
                        }
                    } catch (Exception e) {
                        iv_init_status.setBackgroundColor(getResources().getColor(R.color.red));
                        tv_init_status.setText("初始化失败：");
                        tv_init_gid.setText(e.toString());
                    }
                } else {
                    iv_init_status.setBackgroundColor(getResources().getColor(R.color.red));
                    tv_init_status.setText("初始化失败：");
                    tv_init_gid.setText("errorCode = " + response.getCode());
                }
            }
        });
    }

    /**
     * 注册按钮点击
     * @param view
     */
    public void startAC_register(View view) {
//        Intent intent = new Intent();
//        intent.setClass(this, EventActivity.class);
//        intent.putExtra("event", "register");
//        startActivity(intent);

        Log.i("sjc - ", BrApplication.getInstance().getEncryptGid("25252553522952265252235444950112"));
    }

    /**
     * 登录按钮点击
     * @param view
     */
    public void startAC_logon(View view) {
        Intent intent = new Intent();
        intent.setClass(this, EventActivity.class);
        intent.putExtra("event", "logon");
        startActivity(intent);
    }

    /**
     * 借款按钮点击
     * @param view
     */
    public void startAC_lend(View view) {
        Intent intent = new Intent();
        intent.setClass(this, EventActivity.class);
        intent.putExtra("event", "lend");
        startActivity(intent);
    }

    /**
     * 提现按钮点击
     * @param view
     */
    public void startAC_cash(View view) {
        Intent intent = new Intent();
        intent.setClass(this, EventActivity.class);
        intent.putExtra("event", "cash");
        startActivity(intent);
    }

    /**
     * 还款按钮点击
     * @param view
     */
    public void startAC_repay(View view) {
        Intent intent = new Intent();
        intent.setClass(this, EventActivity.class);
        intent.putExtra("event", "repay");
        startActivity(intent);
    }

    /**
     * 营销
     * @param view
     */
    public void startAC_market(View view) {
        Intent intent = new Intent();
        intent.setClass(this, MarketActivity.class);
        startActivity(intent);
    }

    /**
     * 初始化信息查看
     */
    private void initBtnClick() {
        // 查看请求数据
        icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EntranceActivity.this, RequestInfoActivity.class);
                intent.putExtra("response", responsee.toString());
                intent.putExtra("isInit", true);
                startActivity(intent);
            }
        });
    }
}
