package com.bairong.antifrauddemo.activitys;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.bairong.antifrauddemo.R;
import com.bairong.antifrauddemo.utils.CheckTimeoutUtils;
import com.bairong.mobile.BrAgent;
import com.bairong.mobile.BrEventType;
import com.bairong.mobile.BrResponse;
import com.bairong.mobile.CallBack;

import org.json.JSONObject;

public class EventActivity extends BaseActivity {
    private BrEventType eventType;
    private TextView btn_event;
    private EditText et_user_id;
    private EditText et_business_id;
    private String event;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_event;
    }

    @Override
    protected String getT() {
        event = getIntent().getStringExtra("event");
        switch (event) {
            case "register":
                eventType = BrEventType.BrEventTypeRegister;
                event = "注册";
                break;
            case "logon":
                eventType = BrEventType.BrEventTypeLogin;
                event = "登录";
                break;
            case "lend":
                eventType = BrEventType.BrEventTypeLend;
                event = "借款";
                break;
            case "cash":
                eventType = BrEventType.BrEventTypeCash;
                event = "提现";
                break;
            case "repay":
                eventType = BrEventType.BrEventTypeRepay;
                event = "还款";
                break;
            default:
                eventType = null;
                break;
        }
        return event;
    }

    @Override
    protected boolean getNeedBackIcon() {
        return true;
    }

    @Override
    protected void findViewById() {
        et_user_id = findViewById(R.id.et_user_id);
        et_business_id = findViewById(R.id.et_business_id);
        btn_event = findViewById(R.id.btn_event);
    }

    @Override
    protected void initDate(Bundle savedInstanceState) {
        btn_event.setText("点击" + event);
    }

    public void doEvent(View view) {
        showProgressHUD("请求中");
        String user_id = et_user_id.getText().toString().trim();
        String business_id = et_business_id.getText().toString().trim();
        JSONObject userInfo = null;
        if (!TextUtils.isEmpty(user_id) || !TextUtils.isEmpty(business_id)) {
            try {
                userInfo = new JSONObject();
                if (!TextUtils.isEmpty(user_id)) {
                    userInfo.put("user_id", user_id);
                }
                if (!TextUtils.isEmpty(business_id)) {
                    userInfo.put("business_id", business_id);
                }
            } catch (Exception e) {
                //
            }
        }
        BrAgent.brEvent(this, eventType, userInfo, new CallBack() {
            @Override
            public void message(final BrResponse response) {
                if (response.getStart_time() != 0 && CheckTimeoutUtils.checkTimeout(EventActivity.this, response.getStart_time())) {
                    showToast(EventActivity.this, "授权到期，请联系相关人员");
                    System.exit(0);
                }
                showToast(EventActivity.this, "请求成功");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent();
                        intent.setClass(getApplicationContext(), RequestInfoActivity.class);
                        intent.putExtra("response", response.toString());
                        startActivity(intent);
                        dismissProgressHUD();
                        finish();
                    }
                });
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        BrAgent.setLocationPermissionResult(requestCode, permissions, grantResults);
    }
}
