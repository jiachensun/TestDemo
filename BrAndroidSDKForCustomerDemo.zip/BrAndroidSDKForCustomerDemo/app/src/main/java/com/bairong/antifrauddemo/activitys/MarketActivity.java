package com.bairong.antifrauddemo.activitys;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.bairong.antifrauddemo.R;
import com.bairong.mobile.BrAgent;
import com.bairong.mobile.BrEventType;
import com.bairong.mobile.BrResponse;
import com.bairong.mobile.CallBack;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MarketActivity extends BaseActivity {
    private List<String> getDataSource() {
        List<String> list = new ArrayList<String>();
        list.add("  优惠券 ");
        list.add("   积分 ");
        list.add("   里程 ");
        list.add("   保险 ");
        list.add("   实物 ");
        return list;
    }
    private Spinner spinner;
    private TextView btn_market;
    private EditText et_market_id;
    private BrEventType marketType = BrEventType.BrEventTypeMkCoupon;

    private String marketTypeStr = "优惠券";

    @Override
    protected int getLayoutId() {
        return R.layout.activity_market;
    }

    @Override
    protected String getT() {
        return "营销";
    }

    @Override
    protected boolean getNeedBackIcon() {
        return true;
    }

    @Override
    protected void findViewById() {
        spinner = findViewById(R.id.spinner_market);
        btn_market = findViewById(R.id.btn_market);
        et_market_id = findViewById(R.id.et_market_id);
    }

    @Override
    protected void initDate(Bundle savedInstanceState) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, getDataSource());
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // 1、优惠券，2、积分，3、里程，4、保险，5、实物，6、预留
                // 1、coupon，2、points，3、trip，4、insurance，5、entity，6、reserve
                switch (position) {
                    case 0:
                        marketType = BrEventType.BrEventTypeMkCoupon;
                        marketTypeStr = "优惠券";
                        break;
                    case 1:
                        marketType = BrEventType.BrEventTypeMkPoint;
                        marketTypeStr = "积分";
                        break;
                    case 2:
                        marketType = BrEventType.BrEventTypeMkMileage;
                        marketTypeStr = "里程";
                        break;
                    case 3:
                        marketType = BrEventType.BrEventTypeMkInsure;
                        marketTypeStr = "保险";
                        break;
                    case 4:
                        marketType = BrEventType.BrEventTypeMkArticle;
                        marketTypeStr = "实物";
                        break;
                    case 5:
                        marketType = null;
                        break;
                }
                btn_market.setText("营销-" + marketTypeStr);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    /**
     * 营销
     * @param view
     */
    public void doMarket(View view) {
        showProgressHUD("请求中");
        String marketID = et_market_id.getText().toString().trim();
        JSONObject userInfo = null;
        if (!TextUtils.isEmpty(marketID)) {
            try {
                userInfo = new JSONObject();
                if (!TextUtils.isEmpty(marketID)) {
                    userInfo.put("business_id", marketID);
                }
            } catch (Exception e) {
                //
            }
        }
        BrAgent.brEvent(this, marketType, userInfo, new CallBack() {
            @Override
            public void message(final BrResponse response) {
                showToast(MarketActivity.this, "请求成功");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent();
                        intent.setClass(getApplicationContext(), RequestInfoActivity.class);
                        intent.putExtra("response", response.toString());
                        startActivity(intent);
                        dismissProgressHUD();
                    }
                });
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        BrAgent.setLocationPermissionResult(requestCode, permissions, grantResults);
    }
}
