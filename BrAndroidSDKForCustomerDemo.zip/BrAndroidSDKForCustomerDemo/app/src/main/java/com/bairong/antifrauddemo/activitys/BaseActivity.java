package com.bairong.antifrauddemo.activitys;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.bairong.antifrauddemo.R;
import com.kaopiz.kprogresshud.KProgressHUD;

public abstract class BaseActivity extends AppCompatActivity {
    private KProgressHUD kProgressHUD = null;
    /**
     * 根布局
     */
    private FrameLayout mContentLayout;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_base);

        Toolbar toolbar = findViewById(R.id.base_activity_toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle(getT());
            actionBar.setDisplayHomeAsUpEnabled(getNeedBackIcon());
        }

        mContentLayout = findViewById(R.id.content_base_activity);

        int layoutId = getLayoutId();
        if (layoutId != 0) {
            mContentLayout.addView(LayoutInflater.from(this).inflate(layoutId, null));
        }

        kProgressHUD = KProgressHUD.create(this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setCancellable(false)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f);

        findViewById();
        initDate(bundle);
    }

    protected abstract int getLayoutId();

    protected abstract String getT();

    protected abstract boolean getNeedBackIcon();

    protected abstract void findViewById();

    protected abstract void initDate(Bundle savedInstanceState);

    protected void showProgressHUD(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                kProgressHUD.setLabel(message).show();
            }
        });
    }

    protected void dismissProgressHUD() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                kProgressHUD.dismiss();
            }
        });
    }

    protected void showToast(final Context context, final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}

