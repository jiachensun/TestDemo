package com.bairong.antifrauddemo.activitys;

import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ConsoleMessage;
import android.webkit.GeolocationPermissions;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

import com.bairong.antifrauddemo.R;

public class WebGidActivity extends BaseActivity {

    private WebView webView;
    private EditText et_url;

//    private static final String WEBDEMOURL = "https://anf.bairong.cn/demo/brdtsbfqzfpdemolocalify.html";
    private static final String WEBDEMOURL = "https://anf.bairong.cn/demo/6f3277d6251942d74df330edf66c4d5af1626deb.html";

    @Override
    protected int getLayoutId() {
        return R.layout.activity_web_show;
    }

    @Override
    protected String getT() {
        return "APP内嵌H5";
    }

    @Override
    protected boolean getNeedBackIcon() {
        return true;
    }

    @Override
    protected void findViewById() {
        webView = findViewById(R.id.webview_web_show);
        et_url = findViewById(R.id.et_web_url);
        et_url.setText(WEBDEMOURL);
    }

    @Override
    protected void initDate(Bundle savedInstanceState) {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAppCacheEnabled(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setWebChromeClient(new WebChromeClient(){
            //配置权限（同样在WebChromeClient中实现）
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
                super.onGeolocationPermissionsShowPrompt(origin, callback);
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return super.onConsoleMessage(consoleMessage);
            }
        });

        // 防止点击按钮跳转到浏览器
        webView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
            }
        });

        doLoadUrl();
    }

    private void doLoadUrl() {
        String url = et_url.getText().toString().trim();
        webView.loadUrl(url);
    }
}