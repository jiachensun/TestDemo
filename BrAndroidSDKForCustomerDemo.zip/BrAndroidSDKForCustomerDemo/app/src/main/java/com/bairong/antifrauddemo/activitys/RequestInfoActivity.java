package com.bairong.antifrauddemo.activitys;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;

import com.bairong.antifrauddemo.BrApplication;
import com.bairong.antifrauddemo.R;
import com.bairong.mobile.BrAgent;

/**
 * Created by sjc on 18/5/22.
 */
public class RequestInfoActivity extends BaseActivity {
    @Override
    protected int getLayoutId() {
        return R.layout.activity_show_device_info;
    }

    @Override
    protected String getT() {
        return "采集信息";
    }

    @Override
    protected boolean getNeedBackIcon() {
        return true;
    }

    @Override
    protected void findViewById() {

    }

    @Override
    protected void initDate(Bundle savedInstanceState) {
        boolean isInit = getIntent().getBooleanExtra("isInit", false);
        ((TextView)findViewById(R.id.device_id)).setText(BrAgent.brGetDeviceGid(this));
        String response = getIntent().getStringExtra("response");
        if (!TextUtils.isEmpty(response)) {
            ((TextView) findViewById(R.id.tv_net_response)).setText(stringToJSON(response));
        }
        if (isInit && !TextUtils.isEmpty(BrApplication.getInstance().getInitRequestData())) {
            ((TextView) findViewById(R.id.tv_device_info)).setText(stringToJSON(BrApplication.getInstance().getInitRequestData()));
        } else if (!TextUtils.isEmpty(BrAgent.getRequest())) {
            ((TextView) findViewById(R.id.tv_device_info)).setText(stringToJSON(BrAgent.getRequest()));
        }
    }

    private String stringToJSON(String strJson) {
        if (TextUtils.isEmpty(strJson)) return "";
        // 计数tab的个数
        int tabNum = 0;
        StringBuffer jsonFormat = new StringBuffer();
        int length = strJson.length();

        char last = 0;
        for (int i = 0; i < length; i++) {
            char c = strJson.charAt(i);
            if (c == '{') {
                tabNum++;
                jsonFormat.append(c + "\n");
                jsonFormat.append(getSpaceOrTab(tabNum));
            } else if (c == '}') {
                tabNum--;
                jsonFormat.append("\n");
                jsonFormat.append(getSpaceOrTab(tabNum));
                jsonFormat.append(c);
            } else if (c == ',') {
                jsonFormat.append(c + "\n");
                jsonFormat.append(getSpaceOrTab(tabNum));
            } else if (c == ':') {
                jsonFormat.append(c + " ");
            } else if (c == '[') {
                tabNum++;
                char next = strJson.charAt(i + 1);
                if (next == ']') {
                    jsonFormat.append(c);
                } else {
                    jsonFormat.append(c + "\n");
                    jsonFormat.append(getSpaceOrTab(tabNum));
                }
            } else if (c == ']') {
                tabNum--;
                if (last == '[') {
                    jsonFormat.append(c);
                } else {
                    jsonFormat.append("\n" + getSpaceOrTab(tabNum) + c);
                }
            } else {
                jsonFormat.append(c);
            }
            last = c;
        }
        return jsonFormat.toString();
    }

    // 是空格还是tab
    private String getSpaceOrTab(int tabNum) {
        StringBuffer sbTab = new StringBuffer();
        for (int i = 0; i < tabNum; i++) {
            sbTab.append('\t');
        }
        return sbTab.toString();
    }
}