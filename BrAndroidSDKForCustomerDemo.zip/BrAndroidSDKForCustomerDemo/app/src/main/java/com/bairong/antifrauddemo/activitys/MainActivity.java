package com.bairong.antifrauddemo.activitys;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.bairong.antifrauddemo.BrApplication;
import com.bairong.antifrauddemo.R;
import com.bairong.antifrauddemo.nanohttpd.NanoHTTPD;
import com.bairong.antifrauddemo.utils.CheckTimeoutUtils;
import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;

import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends BaseActivity {

    @Override
    protected int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    protected String getT() {
        return "谛听设备反欺诈";
    }

    @Override
    protected boolean getNeedBackIcon() {
        return false;
    }

    @Override
    protected void findViewById() {

    }

    @Override
    protected void initDate(Bundle savedInstanceState) {
        Logger.addLogAdapter(new AndroidLogAdapter());

        if (CheckTimeoutUtils.checkTimeout(MainActivity.this, System.currentTimeMillis())) {
            showToast(this, "授权到期，请联系相关人员");
            finish();
        }

        if (BrApplication.getInstance().isServer()) {
            startService();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        checkPermissions();
    }

    /**
     * 标准模式
     */
    public void onClickNormal(View view) {
        BrApplication.getInstance().getBrGID();

        Intent intent = new Intent(MainActivity.this, EntranceActivity.class);
        startActivity(intent);
    }

    /**
     * WEB页面展示
     */
    public void onClickShowWEB(View view) {
        Intent intent = new Intent(MainActivity.this, WebGidActivity.class);
        startActivity(intent);
    }

    private long firstTime = 0;
    @Override
    public void onBackPressed() {
        long currentTime = new Date().getTime();
        if (currentTime - firstTime > 3000){
            Toast.makeText(this,"再按一次确认退出",Toast.LENGTH_SHORT).show();
            firstTime = currentTime;
        } else {
            super.onBackPressed();
        }
    }

    /**
     * 需要动态授权的权限
     */
    private ArrayList<String> permissionList = new ArrayList<String>(){{
        add(Manifest.permission.READ_PHONE_STATE);
        add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
    }};

    /**
     * 检查授权情况，对于未授权情况进行动态授权
     */
    private void checkPermissions() {
        ArrayList<String> notPermissionList = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (String permission : permissionList) {
                if (ContextCompat.checkSelfPermission(this, permission)
                        != PackageManager.PERMISSION_GRANTED) {
                    notPermissionList.add(permission);
                }
            }
        }
        if (notPermissionList.size() > 0) {
            String [] needPerissions = notPermissionList.toArray(new String[notPermissionList.size()]);
            ActivityCompat.requestPermissions(this, needPerissions,1);
        }
    }

    /**
     * 开启本地服务
     */
    private void startService() {
        MyHttpserver myHttpserver = new MyHttpserver(8777);
        try {
            myHttpserver.start();
        } catch (Exception e) {
            //
        }
    }

    public void onClickShowLocation(View view) {

        Intent intent = new Intent(MainActivity.this, ShowLocationActivity.class);
        startActivity(intent);
    }

    private static class MyHttpserver extends NanoHTTPD {

        MyHttpserver(int port) {
            super(port);
        }

        @Override
        public Response serve(IHTTPSession session) {
            String uri = session.getUri();
            if (!TextUtils.isEmpty(uri) && uri.equals("/getFingerPrint")) {
                String returnJs = "function getFingerPrint(){return '" + BrApplication.getInstance().getBrGID() + "'}";
                return newFixedLengthResponse(Response.Status.OK, MIME_PLAINTEXT, returnJs);
            }
            return super.serve(session);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mine_setting, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.mine_setting) {
            Intent intent = new Intent(this, SettingActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
