package com.bairong.antifrauddemo.activitys;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

import com.bairong.antifrauddemo.BrApplication;
import com.bairong.antifrauddemo.R;
import com.bairong.mobile.BrLocationType;

import java.io.File;

public class SettingActivity extends BaseActivity {
    private RadioGroup radioGroup_location;
    private EditText et_timeout;
    private Switch switch_compress;
    private Switch switch_encrypt;
    private boolean isCompress = true;
    private boolean isEnc = true;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_setting;
    }

    @Override
    protected String getT() {
        return "设置";
    }

    @Override
    protected boolean getNeedBackIcon() {
        return true;
    }

    @Override
    protected void findViewById() {
        radioGroup_location = findViewById(R.id.radiogroup_location_type);
        et_timeout = findViewById(R.id.et_timeout);
        switch_compress = findViewById(R.id.switch_compress);
        switch_encrypt = findViewById(R.id.switch_encrypt);
    }

    @Override
    protected void initDate(Bundle savedInstanceState) {
        switch_compress.setOnCheckedChangeListener(compressL);
        switch_encrypt.setOnCheckedChangeListener(encryptL);
        updateInitUI();
    }

    private void updateInitUI() {
        if (!TextUtils.isEmpty(BrApplication.getInstance().getTimeout())) {
            et_timeout.setText(BrApplication.getInstance().getTimeout());
        }
        if (BrApplication.getInstance().isCompress()) {
            switch_compress.setChecked(true);
            isCompress = true;
        } else {
            switch_compress.setChecked(false);
            isCompress = false;
        }
        if (BrApplication.getInstance().isEncrypt()) {
            switch_encrypt.setChecked(true);
            isEnc = true;
        } else {
            switch_encrypt.setChecked(false);
            isEnc = false;
        }

        switch (BrApplication.getInstance().getLocationType()) {
            case BrLocaitonTypeNoCollection:
                RadioButton radioButton3 = findViewById(R.id.radiobtn_location_type3);
                radioButton3.setChecked(true);
                break;
            case BrLocaitonTypeRequestAuthorization:
                RadioButton radioButton2 = findViewById(R.id.radiobtn_location_type2);
                radioButton2.setChecked(true);
                break;
            case BrLocaitonTypeDefault:
                RadioButton radioButton1 = findViewById(R.id.radiobtn_location_type1);
                radioButton1.setChecked(true);
                break;
            default:
                RadioButton radioButtonD = findViewById(R.id.radiobtn_location_type1);
                radioButtonD.setChecked(true);
                break;
        }
    }

    /**
     * 保存
     */
    public void onClickSave(View view) {
        showProgressHUD("保存中");
        // 保存所有配置
        BrApplication.getInstance().setTimeout(et_timeout.getText().toString().trim());
        BrApplication.getInstance().setCompress(isCompress);
        BrApplication.getInstance().setEncrypt(isEnc);
        int rbLocationId = radioGroup_location.getCheckedRadioButtonId();
        switch (rbLocationId) {
            case R.id.radiobtn_location_type1:
                BrApplication.getInstance().setLocationType(BrLocationType.BrLocaitonTypeDefault);
                break;
            case R.id.radiobtn_location_type2:
                BrApplication.getInstance().setLocationType(BrLocationType.BrLocaitonTypeRequestAuthorization);
                break;
            case R.id.radiobtn_location_type3:
                BrApplication.getInstance().setLocationType(BrLocationType.BrLocaitonTypeNoCollection);
                break;
            default:
                BrApplication.getInstance().setLocationType(BrLocationType.BrLocaitonTypeDefault);
                break;
        }
        dismissProgressHUD();
        showToast(this, "保存成功");
        finish();
    }

    /**
     * 是否压缩状态
     */
    private CompoundButton.OnCheckedChangeListener compressL = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            isCompress = isChecked;
        }
    };

    /**
     * 是否加密状态
     */
    private CompoundButton.OnCheckedChangeListener encryptL = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            isEnc = isChecked;
        }
    };

    /**
     * 使用SDK默认配置
     * @param view
     */
    public void onClickDefaultSet(View view) {
        switch_compress.setChecked(true);
        isCompress = true;
        switch_encrypt.setChecked(true);
        isEnc = true;
        RadioButton radioButton1 = findViewById(R.id.radiobtn_location_type1);
        radioButton1.setChecked(true);
        et_timeout.setText("3000");
    }

    /**
     * 清除本地缓存GID
     */
    public void clearCacheAll(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("100credit_contents_zw", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("bairong_gid");
        editor.apply();

        File f = Environment.getExternalStorageDirectory();//获取SD卡目录
        String gidFilePath = f.getPath() + "/.gid_bairong";
        File gidFile = new File(gidFilePath);
        if (gidFile.exists()) {
            gidFile.delete();
        }

        String uuidFilePath = f.getPath() + "/.uuid_bairong";
        File uuidFile = new File(uuidFilePath);
        if (uuidFile.exists()) {
            uuidFile.delete();
        }

        showToast(this, "清除成功");
    }
}
